# glpiai-openrouter
GLPI plugins for helpdesk using AI with OpenRouter
